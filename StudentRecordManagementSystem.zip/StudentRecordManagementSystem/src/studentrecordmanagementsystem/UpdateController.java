/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentrecordmanagementsystem;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class UpdateController implements Initializable {
    @FXML
    private TextField name_field;
    @FXML
    private TextField id_field;
    @FXML
    private TextField prog_field;
    @FXML
    private TextField phn_field;
    @FXML
    private TextField email_field;
    @FXML
    private Button updt1_btn;
    @FXML
    private Button logout_field;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Update(ActionEvent event) {
    }

    @FXML
    private void Logout(ActionEvent event) {
    }
    
}
